<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_cortexanalyst';
$plugin->version = 2025050100;
$plugin->requires = 2020061500;